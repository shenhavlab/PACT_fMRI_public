# LM Package
This package contains various utilities that are not directly related to Bayes Factor analysis, but are often useful to compare BF analysis 
with more traditional Null Hypothesis Testing framework tests.