% BAYESFACTOR
% version 1.1 27-JAN-2019
% See https://klabhub.github.io/bayesFactor/ 
%
% Files

%   installBayesFactor - Install the bayesFactor class in Matlab.







